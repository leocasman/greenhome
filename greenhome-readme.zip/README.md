# 🌱 Green Home - Sede Chincha

Este repositorio contiene la página oficial de **Green Home - Sede Chincha**, enfocada en la protección y cuidado del medio ambiente.

---

## 🚀 Publicar en GitHub Pages

Tu página quedará publicada automáticamente en:

👉 **https://leocasman.github.io/greenhome/**

### Pasos para configurar

1. **Sube los archivos al repositorio**
   - Crea un nuevo repositorio llamado `greenhome` en tu cuenta de GitHub (`leocasman`).
   - Sube todos los archivos de este proyecto (`index.html` y la carpeta `images/`).

2. **Verifica la estructura**
   - El archivo `index.html` debe estar en la raíz del repositorio (no dentro de una subcarpeta).
   - La carpeta `images/` debe contener el archivo `logo.png`.

3. **Activa GitHub Pages**
   - En tu repositorio, entra a **Settings > Pages**.
   - En **Source**, selecciona:
     - **Branch:** `main`
     - **Folder:** `/ (root)`
   - Guarda los cambios.

4. **Accede a tu web**
   - Espera 1–5 minutos.
   - Ingresa a 👉 https://leocasman.github.io/greenhome/

---

## 📧 Contacto

**Gerente General:** Leonel Castillón Manrique  
**Correo:** castillonleonel90@gmail.com  
**WhatsApp:** [972316644](https://wa.me/51972316644)

---

© 2025 Green Home - Sede Chincha. Todos los derechos reservados.
